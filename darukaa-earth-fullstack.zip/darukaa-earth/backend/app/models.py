from . import db
from werkzeug.security import generate_password_hash,check_password_hash
class User(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(120)); email=db.Column(db.String(180),unique=True,nullable=False); password_hash=db.Column(db.String(255),nullable=False)
 def set_password(self,p): self.password_hash=generate_password_hash(p)
 def check(self,p): return check_password_hash(self.password_hash,p)
class Project(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(180),nullable=False); type=db.Column(db.String(40),default='carbon'); user_id=db.Column(db.Integer,db.ForeignKey('user.id')); sites=db.relationship('Site',backref='project',cascade='all,delete-orphan')
class Site(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(180),nullable=False); geojson=db.Column(db.Text,nullable=False); project_id=db.Column(db.Integer,db.ForeignKey('project.id'))
