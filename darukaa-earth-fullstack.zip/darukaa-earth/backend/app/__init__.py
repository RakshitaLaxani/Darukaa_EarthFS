import os
from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager

db=SQLAlchemy(); jwt=JWTManager()
def create_app():
    app=Flask(__name__); app.config['SQLALCHEMY_DATABASE_URI']=os.getenv('DATABASE_URL','postgresql+psycopg://postgres:postgres@localhost:5432/darukaa'); app.config['JWT_SECRET_KEY']=os.getenv('JWT_SECRET','dev-secret')
    db.init_app(app); jwt.init_app(app); CORS(app,origins=os.getenv('CORS_ORIGINS','http://localhost:5173').split(','))
    from .routes import bp; app.register_blueprint(bp,url_prefix='/api')
    with app.app_context(): db.create_all()
    return app
