import json
from flask import Blueprint,request
from flask_jwt_extended import create_access_token,jwt_required,get_jwt_identity
from . import db
from .models import User,Project,Site
bp=Blueprint('api',__name__)
@bp.post('/auth/register')
def register():
 d=request.json or {}; 
 if User.query.filter_by(email=d.get('email')).first(): return {'error':'Email already registered'},409
 u=User(name=d.get('name','User'),email=d['email']);u.set_password(d['password']);db.session.add(u);db.session.commit();return {'access_token':create_access_token(str(u.id))}
@bp.post('/auth/login')
def login():
 d=request.json or {};u=User.query.filter_by(email=d.get('email')).first()
 if not u or not u.check(d.get('password','')):return {'error':'Invalid credentials'},401
 return {'access_token':create_access_token(str(u.id))}
@bp.get('/projects')
@jwt_required()
def projects():
 uid=int(get_jwt_identity());return [{'id':p.id,'name':p.name,'type':p.type,'site_count':len(p.sites)} for p in Project.query.filter_by(user_id=uid).all()]
@bp.post('/projects')
@jwt_required()
def create_project():
 uid=int(get_jwt_identity());d=request.json or {};p=Project(name=d['name'],type=d.get('type','carbon'),user_id=uid);db.session.add(p);db.session.commit();return {'id':p.id,'name':p.name},201
@bp.post('/projects/<int:pid>/sites')
@jwt_required()
def create_site(pid):
 uid=int(get_jwt_identity());p=Project.query.filter_by(id=pid,user_id=uid).first_or_404();d=request.json or {};s=Site(name=d.get('name','Site'),geojson=json.dumps(d['geometry']));p.sites.append(s);db.session.commit();return {'id':s.id},201
@bp.get('/projects/<int:pid>')
@jwt_required()
def project(pid):
 uid=int(get_jwt_identity());p=Project.query.filter_by(id=pid,user_id=uid).first_or_404();return {'id':p.id,'name':p.name,'type':p.type,'sites':[{'id':s.id,'name':s.name,'geometry':json.loads(s.geojson)} for s in p.sites]}
