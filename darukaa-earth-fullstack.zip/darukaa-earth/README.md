# Darukaa.Earth

Full-stack geospatial data analytics dashboard for managing and visualizing carbon and biodiversity projects.

## Stack
- Frontend: React + Vite, Mapbox GL JS, Chart.js
- Backend: Python + Flask, JWT authentication
- Database: PostgreSQL + PostGIS (production); SQLite is not used by the app
- CI/CD: GitHub Actions
- Code quality: ESLint/Prettier + pre-commit checks

## Features
- Register/login with JWT
- Project dashboard and project creation
- Interactive Mapbox map
- Draw polygon sites and save them to a project
- Click a site to see analytics and performance over time
- Project/site APIs
- Responsive dashboard UI

## Local setup
1. Install Node.js 20+, Python 3.11+, PostgreSQL with PostGIS, and Git.
2. Backend:
   ```bash
   cd backend
   python -m venv .venv
   # Windows: .venv\\Scripts\\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   copy .env.example .env   # Windows
   # cp .env.example .env  # macOS/Linux
   flask --app run.py run --debug
   ```
3. Frontend:
   ```bash
   cd frontend
   npm install
   copy .env.example .env   # Windows
   # cp .env.example .env  # macOS/Linux
   npm run dev
   ```
4. Create a PostGIS database named `darukaa` and set `DATABASE_URL` in backend `.env`.
5. Set a Mapbox public token in frontend `.env`.

## CI/CD
GitHub Actions runs frontend build/lint and backend compile checks on pushes and pull requests. Production deployment can be connected to Render/Vercel using their GitHub integrations.

## Environment variables
Frontend:
- `VITE_API_URL`
- `VITE_MAPBOX_TOKEN`

Backend:
- `DATABASE_URL`
- `JWT_SECRET`
- `CORS_ORIGINS`

## Submission
The challenge asks for a GitHub repository, public live demo URL, README covering architecture/schema/local setup/CI-CD, and (for private repositories) access for the specified hiring accounts.
